TEAM TVAY

Our final project objective is to develop a social network site where users can interact with each other, similar to the older Facebook and Myspace. 


To execute this assignment 4:
Precondition:
Import the .sql dump file
specify the correct dbusername, dbpassword, mysql database name.

Database username: root
Database password: jeff1239210
mysql database name: social_network

Two input pages with JS functions. login.html and singup.html
