function SignUpvalidate()
        {   
		
            var name  = document.getElementById("username").value;  
			var errors = "";
            if(name == "" || name == null){
			    errors += "UserName must be filled out.\n";
			}
			
			var pass = document.getElementById("pass1").value;
			if(pass == "" || pass == null)
			{
				errors +="Password must be filled out.\n";
			}
			
			var email = document.getElementById("email").value;
			var emailRE = /^.+@.+\..{2,4}$/;
			if(!emailRE.test(email))
			{
				errors += "Invalid email address.\n"
			}
			
			var url = document.getElementById("URL").value;
			if(url == "" || url == null)
			{
				errors +="URL must be filled out.\n";
			}
			
			var first = document.getElementById("first").value;
			if(first == "" || first == null)
			{
				errors +="Fisrtname must be filled out.\n";
			}
			
			var last = document.getElementById("last").value;
			if(last == "" || last == null)
			{
				errors +="Lastname must be filled out.\n";
			}
			
			var city = document.getElementById("city").value;
			if(city == "" || city == null)
			{
				errors +="City must be filled out.\n";
			}
			
			var state = document.getElementById("state").value;
			if(state == "" || state == null)
			{
				errors +="State must be filled out.\n";
			}
			
			if(errors != "")
			{
				alert(errors);
				return false;
			}
			//return false;
        }
		
function checkPass()
		{
			var pass1 = document.getElementById('pass1');
			var pass2 = document.getElementById('pass2');
			var message = document.getElementById('checkingMessage');
			//Set the colors we will be using ...
			var goodColor = "#66cc66";
			var badColor = "#ff6666";
			//Compare the values in the password field 
			//and the confirmation field
			if(pass1.value == pass2.value){
				//The passwords match. 
				//Set the color to the good color and inform
				//the user that they have entered the correct password 
				pass2.style.backgroundColor = goodColor;
				message.style.color = goodColor;
				message.innerHTML = "Passwords Match!"
			}else{
				//The passwords do not match.
				//Set the color to the bad color and
				//notify the user.
				pass2.style.backgroundColor = badColor;
				message.style.color = badColor;
				message.innerHTML = "Passwords Do Not Match!"
			}
		}

function Loginvalidate()
        {   
            var name  = document.forms["loginForm"]["userName"].value;  
            if(name == "" || name == null){
			
				alert("UserName must be filled out");
				return false;
			
			}
        }

	
window.onload = function(){
	var context = document.getElementById('myCanvas').getContext('2d');
	  //shadow
	  context.shadowColor = 'gray';
	  context.shadowBlur = 5;
	  context.shadowOffsetX = -2;
      context.shadowOffsetY = -2;
	  context.fill();

	  //First letter of each word
      context.font = 'bold 50px Arial';
	  context.fillStyle = "blue";
      context.fillText('S', 0, 45);
	  context.fillText('H', 30, 90);

	  //gold letters
	  context.font = 'bold 25px Arial';
	  context.fillStyle = "gold";
	  context.fillText('ocial', 35, 45);
	  context.fillStyle = "gold";
	  context.fillText('ub', 65, 90);
		}
	
