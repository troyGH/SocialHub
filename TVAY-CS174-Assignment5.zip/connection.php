<?php
	//single place to change servername, username, and password
	
	$servername = "localhost";
	$dbusername = "root";
	$dbpassword = "jeff1239210";
?>